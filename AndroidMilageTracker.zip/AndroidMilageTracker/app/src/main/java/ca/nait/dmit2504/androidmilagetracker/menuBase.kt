package ca.nait.dmit2504.androidmilagetracker

class menuBase {
}