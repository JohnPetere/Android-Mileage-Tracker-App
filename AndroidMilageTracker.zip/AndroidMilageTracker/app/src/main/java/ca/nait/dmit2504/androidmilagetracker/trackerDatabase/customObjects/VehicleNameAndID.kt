package ca.nait.dmit2504.androidmilagetracker.trackerDatabase.customObjects

class VehicleNameAndID {
    var vehicleName: String =""
    var vehicleID: Int = 0
}